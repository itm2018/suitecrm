<?php
// created: 2017-01-01 17:54:29
$dictionary["Sales_Order"]["fields"]["sales_order_aos_products_quotes"] = array (
  'name' => 'sales_order_aos_products_quotes',
  'type' => 'link',
  'relationship' => 'sales_order_aos_products_quotes',
  'source' => 'non-db',
  'module' => 'AOS_Products_Quotes',
  'bean_name' => 'AOS_Products_Quotes',
  'side' => 'right',
  'vname' => 'LBL_SALES_ORDER_AOS_PRODUCTS_QUOTES_FROM_AOS_PRODUCTS_QUOTES_TITLE',
);
