<?php
// created: 2017-01-01 17:54:20
$dictionary["Opportunity"]["fields"]["sales_order_opportunities"] = array (
  'name' => 'sales_order_opportunities',
  'type' => 'link',
  'relationship' => 'sales_order_opportunities',
  'source' => 'non-db',
  'module' => 'Sales_Order',
  'bean_name' => false,
  'side' => 'right',
  'vname' => 'LBL_SALES_ORDER_OPPORTUNITIES_FROM_SALES_ORDER_TITLE',
);
